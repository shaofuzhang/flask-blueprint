from flask import Blueprint

calculate_blueprint = Blueprint('calculate', __name__,url_prefix='/calculate')


@calculate_blueprint.route('/')
def home():
    return 'calculate'
    # return render_template('')
